package lab5;

public interface ProdutoInterface {
	
	public String toString();
	
	public double getPreco();
	
	public String getTipoProduto();

	public String getNome();

}
